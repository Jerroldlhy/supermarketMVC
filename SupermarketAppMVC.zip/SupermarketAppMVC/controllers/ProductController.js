﻿const Product = require('../models/product');
const Review = require('../models/review');

const toCurrency = (value, precision = 2) => {
    const numberValue = Number.parseFloat(value);
    if (!Number.isFinite(numberValue) || numberValue < 0) {
        return 0;
    }
    return Number(numberValue.toFixed(precision));
};

const clampDiscount = (value) => {
    const parsed = Number.parseFloat(value);
    if (!Number.isFinite(parsed) || parsed <= 0) {
        return 0;
    }
    if (parsed > 100) {
        return 100;
    }
    return Number(parsed.toFixed(2));
};

const normaliseOfferMessage = (message) => {
    if (!message) {
        return null;
    }
    const trimmed = message.trim();
    if (!trimmed) {
        return null;
    }
    return trimmed.slice(0, 255);
};

const buildProductPayload = (body, image) => {
    const {
        name,
        quantity,
        price,
        discount,
        offer,
        category
    } = body;

    return {
        name: name ? name.trim() : '',
        quantity: Math.max(0, Number.parseInt(quantity, 10) || 0),
        price: toCurrency(price),
        discountPercentage: clampDiscount(discount),
        offerMessage: normaliseOfferMessage(offer),
        image: image || null,
        category: category ? category.trim() || 'General' : 'General'
    };
};

const enhanceProductRecord = (product) => {
    if (!product) {
        return product;
    }

    const basePrice = toCurrency(product.price);
    const discountPercentage = clampDiscount(product.discountPercentage);
    const hasDiscount = discountPercentage > 0;
    const finalPrice = hasDiscount
        ? toCurrency(basePrice * (1 - discountPercentage / 100))
        : basePrice;

    return {
        ...product,
        price: basePrice,
        discountPercentage,
        offerMessage: normaliseOfferMessage(product.offerMessage),
        effectivePrice: finalPrice,
        hasDiscount,
        category: product.category || 'General'
    };
};

const ProductController = {
    // Show the inventory page
    showInventory: (req, res) => {
        Product.getAll((error, results) => {
            if (error) throw error;
            const products = (results || []).map(enhanceProductRecord);
            res.render('inventory', {
                products,
                user: req.session.user,
                messages: res.locals.messages,
                errors: res.locals.errors
            });
        });
    },

    // Show the add product page
    showAddProductForm: (req, res) => {
        res.render('addProduct', {
            user: req.session.user,
            messages: res.locals.messages,
            errors: res.locals.errors
        });
    },

    // Handle product creation
    addProduct: (req, res) => {
        const image = req.file ? req.file.filename : null;
        const productData = buildProductPayload(req.body, image);

        if (!productData.name) {
            req.flash('error', 'Product name is required.');
            return res.redirect('/addProduct');
        }

        Product.create(productData, (error, results) => {
            if (error) {
                console.error("Error adding product:", error);
                res.status(500).send('Error adding product');
            } else {
                req.flash('success', `Product "${productData.name}" added successfully.`);
                res.redirect('/inventory');
            }
        });
    },

    // Show the update product form
    showUpdateProductForm: (req, res) => {
        const productId = req.params.id;
        Product.getById(productId, (error, results) => {
            if (error) throw error;
            if (results.length > 0) {
                res.render('updateProduct', {
                    product: enhanceProductRecord(results[0]),
                    user: req.session.user,
                    errors: res.locals.errors,
                    messages: res.locals.messages
                });
            } else {
                res.status(404).send('Product not found');
            }
        });
    },

    // Handle product update
    updateProduct: (req, res) => {
        const productId = req.params.id;
        let image = req.body.currentImage;

        if (req.file) {
            image = req.file.filename;
        }

        const productData = buildProductPayload(req.body, image);

        if (!productData.name) {
            req.flash('error', 'Product name is required.');
            return res.redirect(`/updateProduct/${productId}`);
        }

        Product.update(productId, productData, (error, results) => {
            if (error) {
                console.error("Error updating product:", error);
                res.status(500).send('Error updating product');
            } else {
                req.flash('success', `Product "${productData.name}" updated successfully.`);
                res.redirect('/inventory');
            }
        });
    },

    // Handle product deletion
    deleteProduct: (req, res) => {
        const productId = req.params.id;

        Product.delete(productId, (error, results) => {
            if (error) {
                console.error("Error deleting product:", error);
                res.status(500).send('Error deleting product');
            } else {
                req.flash('success', 'Product deleted successfully.');
                res.redirect('/inventory');
            }
        });
    },

    // Show individual product details
    showProductDetails: (req, res) => {
        const productId = req.params.id;

        Product.getById(productId, (error, results) => {
            if (error) throw error;
            if (results.length > 0) {
                const product = enhanceProductRecord(results[0]);
                Review.findByProduct(productId, (reviewError, reviewResults) => {
                    if (reviewError) {
                        console.error('Error fetching reviews for product:', reviewError);
                    }

                    const reviews = reviewResults || [];
                    const averageRating = reviews.length
                        ? (reviews.reduce((sum, review) => sum + Number(review.rating || 0), 0) / reviews.length)
                        : null;

                    const userReview = req.session.user
                        ? reviews.find(review => review.user_id === req.session.user.id)
                        : null;

                    res.render('product', {
                        product,
                        user: req.session.user,
                        reviews,
                        averageRating,
                        userReview,
                        messages: res.locals.messages,
                        errors: res.locals.errors
                    });
                });
            } else {
                res.status(404).send('Product not found');
            }
        });
    }
};

module.exports = ProductController;

