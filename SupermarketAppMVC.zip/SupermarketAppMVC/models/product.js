const connection = require('../db');

// Product model
const Product = {
    /**
     * Fetch all products or apply optional filters.
     */
    findByFilter: (filters = {}, callback) => {
        const { category, search } = filters;
        const clauses = [];
        const params = [];

        if (category) {
            clauses.push('category = ?');
            params.push(category);
        }

        if (search) {
            const likeTerm = `%${search}%`;
            clauses.push('(productName LIKE ? OR category LIKE ? OR offerMessage LIKE ?)');
            params.push(likeTerm, likeTerm, likeTerm);
        }

        const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
        const sql = `SELECT * FROM products ${where}`;
        connection.query(sql, params, callback);
    },

    getAll: (callback) => {
        const sql = 'SELECT * FROM products';
        connection.query(sql, callback);
    },

    getByCategory: (category, callback) => {
        const sql = 'SELECT * FROM products WHERE category = ?';
        connection.query(sql, [category], callback);
    },

    getCategories: (callback) => {
        const sql = 'SELECT DISTINCT category FROM products ORDER BY category ASC';
        connection.query(sql, callback);
    },

    getById: (productId, callback) => {
        const sql = 'SELECT * FROM products WHERE id = ?';
        connection.query(sql, [productId], callback);
    },

    create: (productData, callback) => {
        const {
            name,
            quantity,
            price,
            image,
            discountPercentage = 0,
            offerMessage = null,
            category = 'General'
        } = productData;
        const sql = `
            INSERT INTO products
                (productName, quantity, price, discountPercentage, offerMessage, image, category)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `;
        connection.query(sql, [name, quantity, price, discountPercentage, offerMessage, image, category], callback);
    },

    update: (productId, productData, callback) => {
        const {
            name,
            quantity,
            price,
            image,
            discountPercentage = 0,
            offerMessage = null,
            category = 'General'
        } = productData;
        const sql = `
            UPDATE products
            SET productName = ?, quantity = ?, price = ?, discountPercentage = ?, offerMessage = ?, image = ?, category = ?
            WHERE id = ?
        `;
        connection.query(sql, [name, quantity, price, discountPercentage, offerMessage, image, category, productId], callback);
    },

    delete: (productId, callback) => {
        const sql = 'DELETE FROM products WHERE id = ?';
        connection.query(sql, [productId], callback);
    }
};

module.exports = Product;
